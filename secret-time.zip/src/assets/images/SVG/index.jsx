export { ReactComponent as GirlAvatar } from "./girlAvatar.svg";
export { ReactComponent as BoyAvatar } from "./boyAvatar.svg";
