## Usage:

```jsx
<FormPassword name="password" label="Password" py={2} />
// py -> padding top and bottom
```
