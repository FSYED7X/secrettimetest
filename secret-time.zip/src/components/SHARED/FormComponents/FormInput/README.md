## Usage:

```jsx
<FormInput name="unitCode" label="Unit Code" placeholder="YAY4512" py={0} />

// py -> padding top and bottom
```
